<!DOCTYPE html>
<html>

<head>
    <title></title>
</head>

<body>

    <p>Dari: {{ $name }} - {{$email}} - {{$no_hp}}</p>
    <p>{{ $email_body }}</p>
</body>

</html>